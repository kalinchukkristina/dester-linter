"""
A linter to modify LaTeX files.
"""

__version__ = "0.1"