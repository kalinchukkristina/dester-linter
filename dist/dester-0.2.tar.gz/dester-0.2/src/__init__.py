from src.comment_rule import comment_rule_main
from src.blank_line_rule import blank_line_rule_main
from src.indentation_rule import indentation_rule_main
from src.newline_rule import newline_rule_main
from src.dester import main